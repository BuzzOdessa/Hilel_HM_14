﻿namespace Animals.Application.Domain.Animals.Queries.GetAnimalsByName;

public record GetAnimalsByNameQuery();