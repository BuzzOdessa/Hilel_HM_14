﻿namespace Animals.Application.Domain.Animals.Queries.GetAnimals;

public record OwnerDto(string FirstName, string LastName);